package iducs.springboot.blog.service;

import com.zaxxer.hikari.HikariDataSource;
import iducs.springboot.blog.domain.Member;
import iducs.springboot.blog.repository.MemberRepository;
import iducs.springboot.blog.repository.MemberRepositorylmpl;
import iducs.springboot.blog.service.MemberService;
import iducs.springboot.blog.service.MemberServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MemberServiceImplTest {
    Logger logger =  LoggerFactory.getLogger(this.getClass());

    HikariDataSource dataSource;
    MemberService memberService;
    MemberRepository memberRepository;

    @BeforeEach // 각 메소드를 실행하기 전에 동작하는 메소드
    public void BeforeEach() {
        // memberRepository = new MemberRepositorylmpl(dataSource);
        memberService = new MemberServiceImpl(memberRepository); // 같은 memberRepository를 사용(Dependency Injection)
    }
    @Test
    void getMember() {
    }

    @Test
    void getMemberByEmail() {
        Member member = memberService.getMemberByEmail("induk@induk.ac.kr");
        logger.info(member.getPhone());
    }

    @Test
    void getMembers() {
    }

    @Test
    void getMembersByPage() {
    }

    @Test
    void postMember() {
    }

    @Test
    void putMember() {
    }

    @Test
    void deleteMember() {
    }
}
